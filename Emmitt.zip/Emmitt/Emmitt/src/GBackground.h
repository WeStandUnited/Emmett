/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em UBackground.h
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#pragma once
#include "ULib.h"
#include "UTexture.h"
#include "UVector3.h"
#include "GPlayer.h"
#include <vector>




class GBackground {
    // Class constants
    const static int EYE_TILE_WIDTH;
    const static int EYE_TILE_HEIGHT;

public:
    // Initialize the GBackgrounds member variables
    GBackground();

    // Initialize the background object
    bool init(SDL_Renderer*, GPlayer*);

    // Update the background
    void update(const double &);

    // Draw the initial background
    void renderInitial();

    // Draw the tutorial background
    void renderTutorial();

    // Free the resources allocated for this texture
    void free();

private:
    // Background textures
    UTexture mInitialBackground, mTutorialBackground, mEyesTexture;
    
    // Background clips
    SDL_Rect  mEyeClips[10];

    // If the eyes are currently in a waking state
    bool mEyesWaking;
    float mWakeTime;

    // Reference to the player
    GPlayer *mPlayer;

};






