/*
* Copyright 2020 - 2021 Tonia Sanzo �
* Title: Steep Slopes
* Author: Tonia Sanzo
* Date: 12/19/2020
* File: SteepSlopes USound.h
*
* Music & Sound Effects:
* Sound Engineer: Ethan Schwabe
*  
*
* Art:
* Artist: Charles Chiasson
*
*
* Web:
* Designer: Devarsh Panchal
* Link: https://steepslopes.tech/
* 
* 
* Special Thanks to Nicklas Smith
*/
#pragma once
#include <SDL.h>
#include <SDL_mixer.h>
#include <cstdio>

class USound {
public:
    // Initialize the USound member variables
    USound();

    // Initialize the USound object
    bool init();

    // Play the menu music
    void playInitialMusic();

    // Play the angry music
    void playAngryMusic1();

    // Play the really angry music
    void playAngryMusic2();
    
    // Plays the bottle open sound effect
    void openSound();

    // Plays the crash sound
    void crashSound();

    // Toggle the music
    void toggleMusic();

    // Mute the sound
    void toggleMute();

    // Mute status
    bool isMuted() { return mute; }

    // Deallocate and destroy the sounds
    void free();
private:
    // The music, and sound assets used
    Mix_Music *mInitialMusic, *mAngryMusic1, *mAngryMusic2;
    Mix_Chunk *mCrash, *mBottleOpen;

    bool mute;
};