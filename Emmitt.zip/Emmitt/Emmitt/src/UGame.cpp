﻿/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em UGame.cpp
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "UGame.h"




// Default constructor
UGame::UGame()
{
    mRenderer = nullptr;
    mWindow = nullptr;
    prevTime = 0;
    mCurrState = ULib::INITIAL_LEVEL;
    mCurrSong = 0;
}




// Initializes and loads all the game objects
bool UGame::init(SDL_Renderer* aRenderer, UWindow* aWindow)
{
    // Seed random
    srand(time(0));

    // Initialize success flag
    bool success = true;

    // Set the renderer and window
    mRenderer = aRenderer;
    mWindow = aWindow;

    if (mRenderer == nullptr || mWindow == nullptr)
    {
        printf("Attempted to initialize the UGame object with nullptr! Pass in valid pointers in the UGame.init() function\n");
        success = false;
    }
    else
    {
        // Initialize the player
        if (!mPlayer.init(mRenderer, "assets/em_spritesheet.png"))
        {
            printf("Failed to load player!\n");
            success = false;
        }

        // Initialize the bottle sprite sheet
        mBottleTexture.initUTexture(mRenderer);

        if (!mBottleTexture.loadFromFile("assets/bottle_spritesheet.png"))
        {
            printf("Failed to load bottle sprite sheet!\n");
            success = false;
        }
        else
        {
            mBottleTexture.updateScale(.23);
            mBottleTexture.setBlendMode(SDL_BLENDMODE_BLEND);
            mBottleTexture.setAlpha(255);
        }

        // Initialize the sounds
        if (!mSounds.init())
        {
            printf("Failed to load menu music!\n");
            success = false;
        }
        mSounds.playInitialMusic();

        // Initialize the background textures
        if (!mBackground.init(mRenderer, &mPlayer))
        {
            printf("Failed to load background images!\n");
            success = false;
        }
    }


    timer.start();
    return success;
}




// Update the game world based on the time since the last update
void UGame::update(const float& dt)
{
    // Modulate between 0 and 1.5 seconds
    Uint32 currTime = timer.getTicks() % 1500;

    //If the timer modulated once again randomly generate obstacles
    if (prevTime > currTime)
    {
        if (mPlayer.getPlayerState() == GPlayer::PlayerState::AWAKE)
        {
            if (mCurrSong == 0)
            {
                mCurrSong = 1;
                mSounds.playAngryMusic1();
            }
            spawnBottle();
        }
    }

    prevTime = currTime;

    switch (mCurrState)
    {
    case ULib::INITIAL_LEVEL:
        break;

    case ULib::TUTORIAL_LEVEL:
        mPlayer.update(dt);
        mBackground.update(dt);


        bool killBottle = false;
        for (GBottle *&bottle : bottles) {
            bottle->update(dt, &mPlayer);
            if (!bottle->mLive) 
            {
                killBottle = true;
            }
        }

        // Clean up the dead bottles when necessary
        while (killBottle) {
            std::vector<GBottle *>::iterator beg, end;
            for (beg = bottles.begin(), end = bottles.end(); beg != end && (*beg)->mLive; ++beg);

            // Found a dead ramp
            if (beg != end) {
                (*beg)->free();
                delete (*beg);
                bottles.erase(beg);
            }
            // No dead ramps found
            else {
                killBottle = false;
            }
        }

        break;
    }
}





// Handle all the events on the queue
bool UGame::handleEvent(SDL_Event& e)
{
    if (e.type == SDL_QUIT) { return true; }

    switch (mCurrState)
    {
    // Handle events in the initial level
    case ULib::INITIAL_LEVEL:
        // Check to see if the player clicked the start button
        if (e.type == SDL_MOUSEBUTTONDOWN)
        {
            // Get mouse position
            int mosX, mosY;
            SDL_GetMouseState(&mosX, &mosY);

            // Check if mouse is inside the start button
            bool inside = true;

            // Mouse is left of the button
            if (mosX < 543) {
                inside = false;
            }
            // Mouse is right of the button
            else if (mosX > (543 + 193)) {
                inside = false;
            }
            // Mouse is above the planet
            else if (mosY < 457) {
                inside = false;
            }
            // Mouse is below the planet
            else if (mosY > (457 + 46)) {
                inside = false;
            }

            // If the start button was clicked update the game state
            if (inside){ updateGameState(ULib::TUTORIAL_LEVEL); }
        }
        break;

    // Handle events in the tutorial level
    case ULib::TUTORIAL_LEVEL:
        mPlayer.handleEvent(e);
        for (GBottle *&bot : bottles)
        {
            bot->handleEvent(e, &mPlayer, &mSounds);
        }
        break;

    }

    return false;
}




// Draw the game world to the screen
void UGame::render()
{
    switch (mCurrState)
    {
    // Render the intial level
    case ULib::INITIAL_LEVEL:
        mBackground.renderInitial();
        break;
        
    case ULib::TUTORIAL_LEVEL:
        mBackground.renderTutorial();
        mPlayer.render();

        for (GBottle *&bot : bottles)
        {
            bot->render();
        }
        break;
    }

}




void UGame::spawnBottle() 
{
    printf("BOTTLE MADE!\n");

    int spawnlocalgen = rand() % 2;
    UVector3 spawn;

    GBottle *tmpBottle = new GBottle();
    tmpBottle->init(mRenderer, &mBottleTexture);
    bottles.push_back(tmpBottle);
    if (spawnlocalgen == 0) {

        tmpBottle->mPosition = UVector3(-100, 535, 0);
    }
    else {

        tmpBottle->mPosition = UVector3(ULib::SCREEN_DIMENSIONS.x + 100, 535, 0);
    }
}




// Update the game state
void UGame::updateGameState(int aNewState)
{
    mCurrState = aNewState;
    mPlayer.updateGameState(aNewState);
}




// Free the game objects
void UGame::close()
{
    if (mRenderer)
    {
        mRenderer = nullptr;
    }

    if (mWindow)
    {
        mWindow = nullptr;
    }

    // Free member variablews
    mPlayer.free();
    mSounds.free();
    mBackground.free();
    for (GBottle *&bot : bottles) {

        bot->free();
        delete bot;
    }
    bottles.clear();
    mBottleTexture.free();
}