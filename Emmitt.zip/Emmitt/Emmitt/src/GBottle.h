/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em GBottle.h
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#pragma once
#include "ULib.h"
#include "UTexture.h"
#include "GPlayer.h"
#include "UTimer.h"
#include "USound.h"

class GBottle 
{
public:
    // Class constants
    const static int FRAME_WIDTH = 250;
    const static int FRAME_HEIGHT = 396;

    // Initializes Bottle
    GBottle();

    // Initilaize the Bottle object
    bool init(SDL_Renderer *, UTexture *);

    // Updates the bottle
    void update(const float &, GPlayer *);

    // Draw the Bottle
    void render();

    void handleEvent(SDL_Event &, GPlayer *, USound *);

    // Free the resources
    void free();

    // The bottles position
    UVector3 mPosition;
    
    // If the bottle is currently live
    bool mLive;
private:
    const static int FRAME_COUNT = 16;

    // Handles the open scenario
    bool openFlag;
    float mOpenTime;

    // The bottle movement varaibles
    bool mLeft, mRight;
    float mAcceleration;
    float mFriction;
    float mMaxSpeed;
    UVector3 mVel;

    // Timer and variable used for animating player
    UTimer timer;
    Uint32 prevTime;

    //Bottles Sprite sheet , Number of frames ,and current position on sprite sheet
    UTexture *mSpriteSheet;
    SDL_Rect mAnimationFrames[FRAME_COUNT]; 
    int mCurrFrame;
};