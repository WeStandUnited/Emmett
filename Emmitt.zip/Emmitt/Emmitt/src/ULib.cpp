/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em ULib.cpp
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "Ulib.h"




const std::string ULib::TITLE = "Emmitt";
const UVector3 ULib::SCREEN_DIMENSIONS(1280, 760, 0);