/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em GBottle.h
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "GBackground.h"




// Dimesnions of the eye clips
const int GBackground::EYE_TILE_WIDTH  = 1000;
const int GBackground::EYE_TILE_HEIGHT = 250;




// Default constructor
GBackground::GBackground() 
{
    mPlayer = nullptr;
    mWakeTime = 0.f;

    for (int i = 0; i < 10; ++i)
    {
        mEyeClips[i] = SDL_Rect();
    }
}




// Initialize the background textures
bool GBackground::init(SDL_Renderer *aRenderer, GPlayer *aPlayer)
{
    // Tracks members initialization status
    bool success = true;

    mPlayer = aPlayer;

    // Initialize the initial background texture
    mInitialBackground.initUTexture(aRenderer);

    if (!mInitialBackground.loadFromFile("assets/initial_background.png"))
    {
        std::printf("Failed to load initial background texture!\n");
        success = false;
    }
    else
    {
        mInitialBackground.setBlendMode(SDL_BLENDMODE_BLEND);
        mInitialBackground.setAlpha(255);
    }

    // Initialize the tutorial background texture
    mTutorialBackground.initUTexture(aRenderer);

    if (!mTutorialBackground.loadFromFile("assets/tutorial_background.png"))
    {
        std::printf("Failed to load tutorial background texture!\n");
        success = false;
    }
    else
    {
        mInitialBackground.setBlendMode(SDL_BLENDMODE_BLEND);
        mInitialBackground.setAlpha(255);
    }

    // Initialize the eyes sprite sheet
    mEyesTexture.initUTexture(aRenderer);
    if (!mEyesTexture.loadFromFile("assets/eye_spritesheet.png"))
    {
        std::printf("Failed to load eyes texture!\n");
        success = false;
    }
    else
    {
        // Load the eye clips
        for (int row = 0; row < 5; ++row)
        {
            for (int col = 0; col < 2; ++col)
            {
                mEyeClips[(row * 2) + col].x = col * EYE_TILE_WIDTH;
                mEyeClips[(row * 2) + col].y = row * EYE_TILE_HEIGHT;
                mEyeClips[(row * 2) + col].w = EYE_TILE_WIDTH;
                mEyeClips[(row * 2) + col].h = EYE_TILE_HEIGHT;
            }
        }
    }

    return success;
}




// Update the background
void GBackground::update(const double &dt)
{
    if (mEyesWaking == true && mWakeTime < 3.f)
    {
        mWakeTime += dt;
    }
}




// Render the initial background
void GBackground::renderInitial()
{
    mInitialBackground.render(0, 0);
}



// Render the tutorial background
void GBackground::renderTutorial()
{
    //Render the tutorial background
    mTutorialBackground.render(0, 0);

    // Render the eye texture
    int eyeFrame = 4;

    // If this player is currently asleep
    if (mPlayer->getPlayerState() == GPlayer::PlayerState::SLEEPING && !mEyesWaking)
    {
        eyeFrame = 4;
    }
    else 
    {
        if (!mEyesWaking)
        {
            mEyesWaking = true;
            mWakeTime = 0.f;
        }
        else if (mWakeTime < 3.f)
        {
            if (mWakeTime < 1.f)
            {
                eyeFrame = 4;
            }
            else if (mWakeTime < 2.f)
            {
                eyeFrame = 2;
            }
            else
            {
                eyeFrame = 0;
            }
        }
        else
        {
            if (mPlayer->mPosition.x < 200)
            {
                eyeFrame = 9;
            }
            else if (mPlayer->mPosition.x > ULib::SCREEN_DIMENSIONS.x - 200)
            {
                eyeFrame = 5;
            }
            else if (mPlayer->mPosition.x < 500)
            {
                eyeFrame = 0;
            }
            else if (mPlayer->mPosition.x > ULib::SCREEN_DIMENSIONS.x - 500)
            {
                eyeFrame = 3;
            }
            else
            {
                eyeFrame = 1;
            }
        }
    }
    mEyesTexture.render(((ULib::SCREEN_DIMENSIONS.x - EYE_TILE_WIDTH) / 2) , 100, &mEyeClips[eyeFrame]);

    // Fade the initial background out
    if (mInitialBackground.getAlpha() > 0)
    {
        mInitialBackground.setAlpha(mInitialBackground.getAlpha() - 5);
        mInitialBackground.render(0, 0);
    }
}




// Free the resources allocated for this texture
void GBackground::free()
{
    // Free the textures
    mInitialBackground.free();
    mTutorialBackground.free();
    mEyesTexture.free();
    mPlayer = nullptr;
}