/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em GPlayer.h
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#pragma once
#include "ULib.h"
#include "UTexture.h"
#include "UTimer.h"




// Player object
class GPlayer
{
public:
    // Class constants
    const static int FRAME_WIDTH = 130;
    const static int FRAME_HEIGHT = 260;

    // Different states the player can be
    enum class PlayerState
    {
        SLEEPING,
        AWAKE
    };

    // Initializes the player's member variables
    GPlayer();

    // Initilaize the player object
    bool init(SDL_Renderer *, const std::string &);

    // Updates the player
    void update(const float &);

    // Updates the player's current state
    void updateGameState(int);

    // handles event
    void handleEvent(SDL_Event &);

    // Draw the player
    void render();

    // Free the resources
    void free();

    // Get the player state
    PlayerState getPlayerState()
    {
        return mPlayerState;
    }

    // The player's position
    UVector3 mPosition;
private:
    // The current game state, and state of the player
    int mCurrState;
    PlayerState mPlayerState;

    // Number of animation frames
    const static int FRAME_COUNT = 8;

    // Timer and variable used for animating player
    UTimer timer;
    Uint32 prevTime;

    // The players movement variables
    bool mLeft, mRight;
    float mAcceleration;
    float mFriction;
    float mMaxSpeed;
    UVector3 mVel;

    // The players sprite sheet, animation frame, and current animation frame
    UTexture mSpriteSheet;
    SDL_Rect mAnimationFrames[FRAME_COUNT];
    int mCurrFrame;

};