/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em GBottle.cpp
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "GBottle.h"
#include "GPlayer.h"
#include "UVector3.h"




GBottle::GBottle() {
    mCurrFrame = 0;
    mLeft = mRight = false;
    mAcceleration = 2200;
    mFriction = 2175;
    mMaxSpeed = 330;
    mVel = UVector3(0, 0, 0);
    mPosition = UVector3(-100, 625, 0);
    mLive = true;
    openFlag = false;

    for (int i = 0; i < FRAME_COUNT; ++i)
    {
        mAnimationFrames[i] = SDL_Rect();
    }
}




// Initialize the Bottle object
bool GBottle::init(SDL_Renderer *aRenderer, UTexture *aTexture)
{
    // Initialize the success flag
    bool success = true;

   
    // If the texture is the nullptr
    if (!aTexture)
    {
        printf("GBottle was initialized with a non-valid UTexture pointer!\n");
        success = false;
    }
    else
    {
        mSpriteSheet = aTexture;

        // Initialize the animation tiles
        for (int row = 0; row < 3; ++row)
        {   
            for (int col = 0; col < 4; ++col)
            {
                mAnimationFrames[(row * 4) + col].x = col * FRAME_WIDTH;
                mAnimationFrames[(row * 4) + col].y = row * FRAME_HEIGHT;
                mAnimationFrames[(row * 4) + col].w = FRAME_WIDTH;
                mAnimationFrames[(row * 4) + col].h = FRAME_HEIGHT;
            }
        }
    }

    timer.start();
    return success;
}




// Update the bottle
void GBottle::update(const float &dt, GPlayer *aPlayer) {

    Uint32 currentTime = timer.getTicks() % 500;

    if (openFlag)
    {
        mOpenTime += dt;
    }

    if (mOpenTime > 3.f)
    {
        mLive = false;
    }


    if (prevTime > currentTime) {

        mCurrFrame = ++mCurrFrame % 4;
    }

    prevTime = currentTime;

    if (mPosition.x > 3000)
    {
        mLive = false;
    }

    // If the player is to the right of the bottle move right
    if(aPlayer->mPosition.x > mPosition.x)
    {
        if (!openFlag)
        {
            mVel.x += mAcceleration * dt;
        }
        else
        {
            mVel.x -= mAcceleration * dt;
        }
        
    }

    // If the player is to the left of the bottle move left
    else if (aPlayer->mPosition.x < mPosition.x)
    {
        if (!openFlag)
        {
            mVel.x -= mAcceleration * dt;
        }
        else
        {
            mVel.x += mAcceleration * dt;
        }

    }

    // Cap the bottle's speed
    if (mVel.x > mMaxSpeed)
    {
        mVel.x = mMaxSpeed;
    }
    else if (mVel.x < -mMaxSpeed)
    {
        mVel.x = -mMaxSpeed;
    }

    // Set position
    mPosition.x += mVel.x * dt;
}



// Draw the bottle
void GBottle::render()
{

    // If the player is walking
    if (mVel.x != 0)
    {
        if (mVel.x < 0)
        {
            if(!openFlag)
            {
                mSpriteSheet->render((static_cast<int>(mPosition.x - (FRAME_WIDTH * mSpriteSheet->getScale() / 2.0))), static_cast<int>(mPosition.y - (FRAME_HEIGHT * mSpriteSheet->getScale() / 2.0)), &mAnimationFrames[mCurrFrame], 0, nullptr, SDL_FLIP_HORIZONTAL);
            }
            else
            {
                mSpriteSheet->render((static_cast<int>(mPosition.x - (FRAME_WIDTH * mSpriteSheet->getScale() / 2.0))), static_cast<int>(mPosition.y - (FRAME_HEIGHT * mSpriteSheet->getScale() / 2.0)), &mAnimationFrames[mCurrFrame + 8], 0, nullptr, SDL_FLIP_HORIZONTAL);
            }
        }
        else
        {
            if (!openFlag)
            {
                mSpriteSheet->render((static_cast<int>(mPosition.x - (FRAME_WIDTH * mSpriteSheet->getScale() / 2.0))), static_cast<int>(mPosition.y - (FRAME_HEIGHT * mSpriteSheet->getScale() / 2.0)), &mAnimationFrames[mCurrFrame]);
            }
            else
            {
                mSpriteSheet->render((static_cast<int>(mPosition.x - (FRAME_WIDTH * mSpriteSheet->getScale() / 2.0))), static_cast<int>(mPosition.y - (FRAME_HEIGHT * mSpriteSheet->getScale() / 2.0)), &mAnimationFrames[mCurrFrame + 8]);
            }
        }
    }
    else
    {
        mSpriteSheet->render((static_cast<int>(mPosition.x - (FRAME_WIDTH * mSpriteSheet->getScale() / 2.0))), static_cast<int>(mPosition.y - (FRAME_HEIGHT * mSpriteSheet->getScale() / 2.0)), &mAnimationFrames[mCurrFrame]);
    }
}




// Handle the user events
void GBottle::handleEvent(SDL_Event &e, GPlayer *aPlayer, USound *aSounds)
{
    // If a key was pressed
    if (e.type == SDL_KEYDOWN && e.key.repeat == 0)
    {
        switch (e.key.keysym.sym)
        {
        case SDLK_SPACE:
            printf("bottle event space.\n");
            // If the bottle is overlapping the player open the bottle
            if (mPosition.x > (aPlayer->mPosition.x - ((aPlayer->FRAME_WIDTH * .74) / 2.0)) && mPosition.x < (aPlayer->mPosition.x + ((aPlayer->FRAME_WIDTH * .74) / 2.0)))
            {
                printf("BOTTLE OPEN!\n");
                aSounds->openSound();
                openFlag = true;
                mOpenTime = 0;


            }

            break;

        }
    }
}




// Deallocate the bottle's resources
void GBottle::free()
{
    if (mSpriteSheet)
    {
        mSpriteSheet = nullptr;
    }
}