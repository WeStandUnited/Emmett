/**
* Copyright 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em UGame.h
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#pragma once
#include "ULib.h"
#include "UWindow.h"
#include "GPlayer.h"
#include "USound.h"
#include "GBottle.h"
#include "GBackground.h"
#include "UTimer.h"




class UGame
{
public:
    // Initializes internals
    UGame();

    // Initialize the game objects
    bool init(SDL_Renderer *, UWindow *);

    // Updates the game world
    void update(const float &);

    // Handle's events
    bool handleEvent(SDL_Event &);

    // Draw game world
    void render();

    // Update the game state, and trhe game states of the member variables
    void updateGameState(int);

    // Spawn the bottles
    void spawnBottle();

    // Free the resources
    void close();

private:
    // The games current state
    int mCurrState;

    // Game timer and prev recorded time
    UTimer timer;
    Uint32 prevTime;

    // Game renderer, window, and sounds
    SDL_Renderer *mRenderer;
    UWindow *mWindow;
    USound mSounds;
    char mCurrSong;

    // The backgrounds
    GBackground mBackground;

    // The player
    GPlayer mPlayer;

    // The bottles
    UTexture mBottleTexture;
    std::vector<GBottle *> bottles;
};