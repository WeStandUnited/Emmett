/**
* CopymRight 2021 Goblin HQ �
* Title: Em
* Date: 2/21/2021
* File: Em USound.cpp
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "USound.h"




// Initialize USound member variables
USound::USound() {
    mInitialMusic = nullptr;
    mAngryMusic1 = nullptr;
    mAngryMusic2 = nullptr;
    mBottleOpen = nullptr;
    mCrash = nullptr;
    mute = false;
}




// Initialize the USound object
bool USound::init() {
    bool success = true;

    // Load the menu music
    mInitialMusic = Mix_LoadMUS("assets/menu_mus.wav");
    if (mInitialMusic == nullptr) {
        printf("Failed to load music! SDL_mixer Error: %s\n", Mix_GetError());
        success = false;
    }

    // Load the angry 1 music
    mAngryMusic1 = Mix_LoadMUS("assets/angry_mus1.wav");
    if (mAngryMusic1 == nullptr) {
        printf("Failed to load music! SDL_mixer Error: %s\n", Mix_GetError());
        success = false;
    }

    // Load the angry 2 music
    mAngryMusic2 = Mix_LoadMUS("assets/angry_mus2.wav");
    if (mAngryMusic2 == nullptr) {
        printf("Failed to load music! SDL_mixer Error: %s\n", Mix_GetError());
        success = false;
    }

    // Load the bottle open sound effect
    mBottleOpen = Mix_LoadWAV("assets/bottle_pop.wav");
    if (mBottleOpen == nullptr) {
        printf("Failed to load jump sound! SDL_mixer Error: %s\n", Mix_GetError());
        success = false;
    }

    // Load the crash sound effect
    mCrash = Mix_LoadWAV("assets/bottle_grab.wav");
    if (mCrash == nullptr) {
        printf("Failed to load land sound! SDL_mixer Error: %s\n", Mix_GetError());
        success = false;
    }

    return success;
}




// Play menu music
void USound::playInitialMusic() {
    // If there is music playing
    if (Mix_PlayingMusic() != 0) {
        // Stop the music
        Mix_HaltMusic();
    }

    // Play the menu music
    Mix_PlayMusic(mInitialMusic, -1);

    // If it is currently muted
    if (mute) {
        // Pause the music
        Mix_PauseMusic();
    }
}




// Play angry 1 music
void USound::playAngryMusic1() {
    // If there is music playing
    if (Mix_PlayingMusic() != 0) {
        // Stop the music
        Mix_HaltMusic();
    }

    // Play the game music
    Mix_PlayMusic(mAngryMusic1, -1);

    // If it is currently muted
    if (mute) {
        // Pause the music
        Mix_PauseMusic();
    }
}




// Play angry 2 music
void USound::playAngryMusic2() {
    // If there is music playing
    if (Mix_PlayingMusic() != 0) {
        // Stop the music
        Mix_HaltMusic();
    }

    // Play the game music
    Mix_PlayMusic(mAngryMusic2, -1);

    // If it is currently muted
    if (mute) {
        // Pause the music
        Mix_PauseMusic();
    }
}




// Plays the Bottle open sound effect
void USound::openSound() {
    if (!mute)
    {
        Mix_PlayChannel(-1, mBottleOpen, 0);
    }
}




// Plays the button sound effect
void USound::crashSound() {
    if (!mute)
    {
        Mix_PlayChannel(-1, mCrash, 0);
    }
}




// Toggle the music
void USound::toggleMusic() {
    // If the music is paused
    if (Mix_PausedMusic() == 1) {
        // Resume the music
        Mix_ResumeMusic();
    }
    // If the music is playing
    else {
        // Pause the music
        Mix_PauseMusic();
    }
}




// Mute the sound
void USound::toggleMute()
{
    if (mute)
    {
        mute = false;
    }

    else
    {
        mute = true;
    }
}




// Deallocate and destroy the sounds
void USound::free(){
    // Music is playing
    if (Mix_PlayingMusic() != 0) {
        // Stop the music
        Mix_HaltMusic();
    }

    // Free menu music
    Mix_FreeMusic(mInitialMusic);
    mInitialMusic = nullptr;

    // Free play music
    Mix_FreeMusic(mAngryMusic1);
    mAngryMusic1 = nullptr;

    // Free the jump sound effect
    Mix_FreeMusic(mAngryMusic2);
    mAngryMusic2 = nullptr;

    // Free the bottle open sound effect
    Mix_FreeChunk(mBottleOpen);
    mBottleOpen = nullptr;

    // Free the crash sound effect
    Mix_FreeChunk(mCrash);
    mCrash = nullptr;
}