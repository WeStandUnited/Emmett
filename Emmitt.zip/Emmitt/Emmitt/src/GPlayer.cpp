/**
* CopymRight 2021 Goblin HQ �
* Title: Em
* Date: 2/20/2021
* File: Em GPlayer.cpp
*
* Engineers: Charles Chiasson, Tonia Sanzo
* Audio:     Ethan Schwabe
* Art:       Bobbierre Heard, Bharati Mahajan, Ngan Nguyen
*/
#include "GPlayer.h"




// Initializes the player's member variables
GPlayer::GPlayer()
{
    mCurrState = ULib::INITIAL_LEVEL;
    mPlayerState = PlayerState::SLEEPING;
    mCurrFrame = 0;
    mLeft = mRight = false;
    mAcceleration = 3000;
    mFriction = 2175;
    mMaxSpeed = 277;
    mVel = UVector3(0,0,0);
    mPosition = UVector3(ULib::SCREEN_DIMENSIONS.x / 2, 485, 0);

    // Initialize the animation frames
    for (int i = 0; i < FRAME_COUNT; ++i)
    {
        mAnimationFrames[i] = SDL_Rect();
    }
}




// Initialize the player object
bool GPlayer::init(SDL_Renderer *aRenderer, const std::string &path)
{
    // Initialize the success flag
    bool success = true;

    // Initialize the player sprite sheet
    mSpriteSheet.initUTexture(aRenderer);

    // Load the sprite sheet with the file path
    if (!mSpriteSheet.loadFromFile(path))
    {
        printf("Failed to load player sprite sheet!\n");
        success = false;
    }
    else
    {
        mSpriteSheet.updateScale(.8);

        for (int row = 0; row < 2; ++row)
        {
            for (int col = 0; col < 4; ++col)
            {
                mAnimationFrames[(row * 4) + col].x = FRAME_WIDTH * col;
                mAnimationFrames[(row * 4) + col].y = FRAME_HEIGHT * row;
                mAnimationFrames[(row * 4) + col].w = FRAME_WIDTH;
                mAnimationFrames[(row * 4) + col].h = FRAME_HEIGHT;
            }
        }
    }

    timer.start();

    return success;

}




// Updates the player
void GPlayer::update(const float &dt)
{
    // Modulate between 0 and .33 seconds
    Uint32 currTime = timer.getTicks() % 330;

    // If the timer modulated once again increment the currFrame
    if (prevTime > currTime)
    {
        mCurrFrame = ((++mCurrFrame) % 4);
    }

    prevTime = currTime;

    switch (mCurrState)
    {
    case ULib::TUTORIAL_LEVEL:
    case ULib::ANGER_LEVEL:
        // Apply stopping mFriction only if the player is stopped
        if (!mLeft && !mRight)
        {
            // Apply mFriction
            if (mVel.x > 0)
            {
                mVel.x -= mFriction * dt;

                // Prevent mFriction from pushing the player in the opposite direction
                if (mVel.x < 0) { mVel.x = 0; }
            }
            else if (mVel.x < 0)
            {
                mVel.x += mFriction * dt;

                // Prevent mFriction from pushing the player in the opposite direction
                if (mVel.x > 0) { mVel.x = 0; }
            }
        }
        else
        {
            // If the player was sleeping wake them up
            if (mPlayerState == PlayerState::SLEEPING)
            {
                mPlayerState = PlayerState::AWAKE;
            }

            // Update the player's velocity
            if (mLeft)
            {
                mVel.x -= mAcceleration * dt;
                mLeft = false;
            }

            if (mRight)
            {
                mVel.x += mAcceleration * dt;
                mRight = false;
            }
        }


        // Cap the player's speed
        if (mVel.x > mMaxSpeed)
        {
            mVel.x = mMaxSpeed;
        }
        else if (mVel.x < -mMaxSpeed)
        {
            mVel.x = -mMaxSpeed;
        }

        // Set position
        mPosition.x += mVel.x * dt;
        
        break;
    }
}




// Update the current game state
void GPlayer::updateGameState(int aNewState)
{
    mCurrState = aNewState;
}




// Handle the events
void GPlayer::handleEvent(SDL_Event &e)
{
    // If a key was pressed
    if (e.type == SDL_KEYDOWN)
    {
        switch (e.key.keysym.sym)
        {
        case SDLK_SPACE:
            printf("Player event space.\n");
            break;

        case SDLK_LEFT:
            printf("Player event mLeft arrow.\n");
            mLeft = true;
            break;

        case SDLK_RIGHT:
            printf("Player event mRight arrow.\n");
            mRight = true;
            break;

        }
    }
}




// Draw the player
void GPlayer::render()
{
    // If the player is walking
    if (mVel.x != 0)
    {
        if (mVel.x < 0)
        {
            mSpriteSheet.render(static_cast<int>(mPosition.x) - ((FRAME_WIDTH * mSpriteSheet.getScale()) / 2), static_cast<int>(mPosition.y) - (FRAME_HEIGHT * mSpriteSheet.getScale()) / 2, &mAnimationFrames[mCurrFrame + 4]);
        }
        else
        {
            mSpriteSheet.render(static_cast<int>(mPosition.x) - ((FRAME_WIDTH * mSpriteSheet.getScale()) / 2), static_cast<int>(mPosition.y) - (FRAME_HEIGHT * mSpriteSheet.getScale()) / 2, &mAnimationFrames[mCurrFrame + 4], 0, nullptr, SDL_FLIP_HORIZONTAL);
        }
    }
    else
    {
        mSpriteSheet.render(static_cast<int>(mPosition.x) - ((FRAME_WIDTH * mSpriteSheet.getScale()) / 2), static_cast<int>(mPosition.y) - (FRAME_HEIGHT * mSpriteSheet.getScale()) / 2, &mAnimationFrames[mCurrFrame]);
    }
}




// Deallocate the hamster's resources
void GPlayer::free()
{
    mSpriteSheet.free();
}